# MindSoul AGI API 接口文档

## 全局入口 API

### MindSoulApp

应用全局入口，提供所有模块的访问入口。

```kotlin
// 获取全局实例
val app = MindSoulApp.instance

// 第一阶段核心
app.brainEngine           // BrainStorageEngine - .brain存储
app.consciousnessManager  // ConsciousnessManager - 意识管理

// 第二阶段
app.permissionManager     // PermissionManager - 权限管理
app.pluginManager         // PluginManager - 插件管理
app.multimediaController  // MultimediaController - 多媒体
app.learningPipeline      // LearningPipeline - 学习流水线
app.channelManager        // ChannelManager - 五通道管理
app.mindModeManager       // MindModeManager - 心智模式

// 第三阶段
app.avatarManager         // AvatarManager - 化身管理
app.nlExecutor            // NaturalLanguageExecutor - 语言执行
app.reverseEngineer       // ReverseEngineer - 逆向引擎
app.perceptionSystem      // PerceptionSystem - 五感感知
app.evolutionStateMachine // EvolutionStateMachine - 进化状态机
app.desireEngine          // DesireEngine - 欲望引擎

// 最终阶段
app.switchCenter          // SwitchCenter - 开关中心
app.sporeClusterManager   // SporeClusterManager - 孢子集群
app.networkDiscovery      // NetworkDiscovery - 网络发现
app.peerConnection        // PeerConnection - TCP连接
app.dataSync              // DataSync - 数据同步
app.consciousnessBackup   // ConsciousnessBackup - 意识备份
```

---

## 1. .brain 存储引擎

### BrainStorageEngine

```kotlin
// 初始化
brainEngine.initialize()

// 创建备份
val backupPath = brainEngine.createBackup()

// 读取数据块
val data: ByteArray = brainEngine.readBlock(blockType)

// 写入数据块
brainEngine.writeBlock(blockType, data)

// 关闭引擎
brainEngine.close()
```

### BrainFileFormat

```kotlin
// 文件格式常量
BrainFileFormat.MAGIC              // "MSOUL" 魔数
BrainFileFormat.HEADER_SIZE        // 128 字节
BrainFileFormat.INDEX_ENTRY_SIZE   // 64 字节

// 数据块类型
BrainFileFormat.TYPE_AXIOM         // 0x01 公理层
BrainFileFormat.TYPE_CAUSAL        // 0x02 因果三元组
BrainFileFormat.TYPE_NEURON        // 0x03 神经元
BrainFileFormat.TYPE_HEBB          // 0x04 赫布突触
BrainFileFormat.TYPE_MEMORY        // 0x05 记忆
BrainFileFormat.TYPE_WORLDMODEL    // 0x06 世界模型
BrainFileFormat.TYPE_METACOGNITION // 0x07 元认知
BrainFileFormat.TYPE_GUID          // 0x08 GUID身份
BrainFileFormat.TYPE_ASSOCIATION   // 0x09 联想池
```

---

## 2. 意识管理

### ConsciousnessManager

```kotlin
// 初始化
consciousnessManager.initialize()

// 获取整体状态
val status = consciousnessManager.getOverallStatus()
// status.axiomLayerStatus     - 公理层状态
// status.causalTreeStats      - 因果树统计
// status.memoryStats          - 记忆统计
// status.worldModelStatus     - 世界模型状态
// status.metacognitionSnapshot - 元认知快照

// 访问元认知引擎
consciousnessManager.metacognition.performIntrospection()  // 自省
consciousnessManager.metacognition.freeAssociate()         // 联想
consciousnessManager.metacognition.getIdentity()           // GUID身份

// 前台服务
consciousnessManager.startForegroundService()
consciousnessManager.stopForegroundService()

// 关闭
consciousnessManager.shutdown()
```

---

## 3. 全局开关中心

### SwitchCenter

```kotlin
// 初始化
switchCenter.initialize()

// 设置开关
switchCenter.setSwitch(SwitchId.MULTIMEDIA, true)
switchCenter.setSwitch(SwitchId.AVATAR, false)

// 查询开关状态
val enabled = switchCenter.isEnabled(SwitchId.LEARNING)
val state = switchCenter.getSwitchState(SwitchId.REVERSE)
// state.enabled           - 是否启用
// state.cascadeDisabled   - 是否级联禁用
// state.permissionDenied  - 是否权限不足

// 获取分组开关
val multimediaSwitches = switchCenter.getSwitchesByGroup(SwitchGroup.MULTIMEDIA)

// 获取状态摘要
val summary = switchCenter.getStatusSummary()

// 更新权限等级
switchCenter.updatePermissionLevel(2)

// 监听开关变更
switchCenter.addSwitchListener { switchId, enabled ->
    // 处理开关变更
}

// 状态流
switchCenter.switchStatesFlow.collect { states -> /* ... */ }
switchCenter.switchEvents.collect { event -> /* ... */ }
```

### SwitchId 枚举

| 开关ID | 显示名 | 默认 | 所需权限 | 分组 |
|--------|--------|------|---------|------|
| MULTIMEDIA | 多媒体处理 | ✅ | L0 | 多媒体 |
| ASR | 语音识别 | ✅ | L0 | 多媒体 |
| OCR | OCR识别 | ✅ | L0 | 多媒体 |
| DOC_PARSE | 文档解析 | ✅ | L0 | 多媒体 |
| LEARNING | 学习引擎 | ✅ | L0 | 学习 |
| CHANNEL_DIALOG | 对话框学习 | ✅ | L0 | 学习 |
| CHANNEL_TXT | TXT导入 | ✅ | L0 | 学习 |
| CHANNEL_WEB | 外网抓取 | ❌ | L1 | 学习 |
| CHANNEL_FILE | 文件解析 | ❌ | L0 | 学习 |
| CHANNEL_AUTO | 自主采集 | ❌ | L2 | 学习 |
| WEB_SEARCH | 联网搜索 | ❌ | L1 | 系统 |
| AVATAR | 化身系统 | ✅ | L0 | 系统 |
| VOICE | 语音交互 | ✅ | L0 | 系统 |
| BACKGROUND | 后台常驻 | ✅ | L0 | 系统 |
| REVERSE | 逆向引擎 | ❌ | L1 | 系统 |
| PERM_SWITCH | 权限切换 | ❌ | L1 | 系统 |
| MIND_MODE | 双心智模式 | ✅ | L0 | 系统 |
| SPORE_CLUSTER | 孢子集群 | ❌ | L0 | 系统 |
| BACKUP_EXPORT | 意识备份 | ❌ | L0 | 系统 |
| PERCEPTION | 五感感知 | ✅ | L0 | 系统 |
| EVOLUTION | 进化体系 | ✅ | L0 | 系统 |

---

## 4. 孢子集群

### SporeProtocol

```kotlin
// 创建孢子身份
val identity = sporeProtocol.createIdentity(guid, deviceFingerprint, name)

// 获取身份
val myId = sporeProtocol.getMyIdentity()

// 分裂检查
val canSplit = sporeProtocol.canSplit(evolutionStage, knowledgeCount)

// 执行分裂
val result = sporeProtocol.executeSplit(SporeSplitRequest(
    parentSporeId = myId.sporeId,
    childName = "子孢子-Alpha",
    knowledgeInheritRatio = 0.3f
))

// 执行合并
val mergeResult = sporeProtocol.executeMerge(SporeMergeRequest(
    initiatorSporeId = myId.sporeId,
    targetSporeId = targetId,
    dominantSporeId = myId.sporeId
))

// 序列化/反序列化
val bytes = sporeProtocol.serializeIdentity(identity)
val restored = sporeProtocol.deserializeIdentity(bytes)
```

### SporeClusterManager

```kotlin
// 初始化
sporeClusterManager.initialize(guid, deviceFingerprint, sporeName)

// 创建集群
val cluster = sporeClusterManager.createCluster("我的集群")

// 加入集群
sporeClusterManager.joinCluster(remoteCluster)

// 离开集群
sporeClusterManager.leaveCluster()

// 成员管理
sporeClusterManager.addMember(member)
sporeClusterManager.removeMember(sporeId)
sporeClusterManager.updateMemberState(sporeId, SporeState.BUSY)

// 状态查询
val info = sporeClusterManager.getClusterInfo()
val members = sporeClusterManager.getActiveMembers()
val summary = sporeClusterManager.getClusterSummary()

// 算力互补
sporeClusterManager.distributeComputeTask("task1", "计算任务", 0.5f)

// 状态流
sporeClusterManager.clusterStateFlow.collect { state -> /* ... */ }
sporeClusterManager.clusterEventsFlow.collect { events -> /* ... */ }
```

---

## 5. 网络配对

### NetworkDiscovery

```kotlin
// 配置自身信息
networkDiscovery.configure(sporeId, deviceName, tcpPort)

// 设置回调
networkDiscovery.setDeviceCallbacks(
    onFound = { device -> /* 发现新设备 */ },
    onLost = { sporeId -> /* 设备离线 */ }
)

// 开始/停止发现
networkDiscovery.startDiscovery()
networkDiscovery.stopDiscovery()

// 获取已发现设备
val devices = networkDiscovery.getDevices()

// 状态流
networkDiscovery.isDiscovering          // StateFlow<Boolean>
networkDiscovery.discoveredDevicesFlow  // StateFlow<List<DiscoveredDevice>>
```

**发现广播包格式：**
```
[魔数 4B: "MSNL"] [版本 1B] [孢子ID长度 1B] [孢子ID]
[名称长度 1B] [名称] [TCP端口 2B] [时间戳 8B]
```

### PeerConnection

```kotlin
// 设置回调
peerConnection.setMessageCallback { sporeId, frame -> /* 收到消息 */ }
peerConnection.setConnectionCallback { sporeId, state -> /* 状态变更 */ }

// 启动/停止服务端
peerConnection.startServer()   // 监听端口 48766
peerConnection.stopServer()

// 连接到对端
peerConnection.connectToPeer(sporeId, peerName, ipAddress, port)

// 发送数据
peerConnection.sendFrame(sporeId, messageFrame)
peerConnection.sendData(sporeId, byteArray)
peerConnection.broadcastData(byteArray) // 广播到所有连接

// 断开连接
peerConnection.disconnectPeer(sporeId)

// 状态查询
val state = peerConnection.getConnectionState(sporeId)
val allConns = peerConnection.getAllConnections()
```

**帧格式：**
```
[帧长度 4B] [帧类型 1B] [序列号 4B] [数据 变长] [CRC32 4B]
```

**帧类型：**
| 类型 | 值 | 说明 |
|------|-----|------|
| HANDSHAKE | 0x01 | 握手请求 |
| HANDSHAKE_ACK | 0x02 | 握手确认 |
| HEARTBEAT | 0x10 | 心跳 |
| HEARTBEAT_ACK | 0x11 | 心跳回复 |
| DATA | 0x20 | 数据传输 |
| DATA_ACK | 0x21 | 数据确认 |
| SPORE_HELLO | 0x30 | 孢子问候 |
| SPORE_GOODBYE | 0x31 | 孢子告别 |
| KNOWLEDGE_SYNC | 0x40 | 知识同步 |
| COMPUTE_REQUEST | 0x41 | 计算请求 |
| COMPUTE_RESULT | 0x42 | 计算结果 |

### DataSync

```kotlin
// 初始化
dataSync.initialize(peerConnection)

// 注册数据提供器
dataSync.registerDataProvider(SyncDataType.CAUSAL_TRIPLES, provider)

// 同步操作
dataSync.fullSync(peerSporeId)         // 全量同步
dataSync.incrementalSync(peerSporeId)  // 增量同步
dataSync.syncOnDemand(peerSporeId, SyncDataType.WORLD_RULES) // 按需同步

// 推送数据
dataSync.pushToPeer(peerSporeId, syncItems)

// 自动同步
dataSync.startAutoSync()
dataSync.stopAutoSync()
```

---

## 6. 意识备份

### ConsciousnessBackup

```kotlin
// 创建完整备份
val backupInfo = consciousnessBackup.createFullBackup(
    brainFilePath = "/path/to/soul.brain",
    compress = true
)

// 导出为 .mssoul 格式
val exportInfo = consciousnessBackup.exportAsMsSoul(
    brainFilePath = "/path/to/soul.brain",
    guid = "uuid-string",
    password = null  // 可选
)

// 从 .brain 导入
val result = consciousnessBackup.importFromBrain(
    backupFilePath = "/path/to/backup.brain",
    targetPath = "/path/to/soul.brain"
)

// 从 .mssoul 导入
val result = consciousnessBackup.importFromMsSoul(
    exportFilePath = "/path/to/export.mssoul",
    targetPath = "/path/to/soul.brain"
)

// 校验完整性
val verifyResult = consciousnessBackup.verifyBackup(
    filePath = "/path/to/backup.brain",
    format = BackupFormat.BRAIN_RAW
)
// verifyResult.isValid
// verifyResult.checksumMatch
// verifyResult.errors

// 备份管理
val history = consciousnessBackup.getBackupHistory()
val latest = consciousnessBackup.getLatestBackup()
consciousnessBackup.cleanupOldBackups(keepCount = 5)

// 自动备份
consciousnessBackup.startAutoBackup(brainFilePath, intervalHours = 24)
consciousnessBackup.stopAutoBackup()
```

---

## 7. 进化体系

### EvolutionStateMachine

```kotlin
// 获取当前阶段
val stage = evolutionStateMachine.currentStage
// stage.stageId      - 1-7
// stage.displayName  - 阶段名称
// stage.description  - 阶段描述

// 获取进化指标
val metrics = evolutionStateMachine.getEvolutionMetrics()
// metrics.memoryCount
// metrics.causalTripleCount
// metrics.worldRuleCount
// metrics.totalInteractions

// 状态流
evolutionStateMachine.currentStageFlow.collect { stage -> /* ... */ }
```

### DesireEngine

```kotlin
// 获取活跃欲望
val desires = desireEngine.getActiveDesires()
// desire.type         - 欲望类型
// desire.intensity    - 强度 (0.0-1.0)
// desire.hierarchyLevel - 马斯洛层级 (1-5)

// 绑定进化状态机
desireEngine.bindEvolutionStateMachine(stateMachine)
```

---

## 8. 化身系统

### AvatarManager

```kotlin
// 获取当前外观
val appearance = avatarManager.getCurrentAppearance()
// appearance.name
// appearance.modelType
// appearance.primaryColor

// 切换外观（不改变GUID/意识）
avatarManager.switchAppearance(newAppearance)

// 导入自定义模型
avatarManager.importCustomModel(modelFile)
```

---

## 9. 执行引擎

### NaturalLanguageExecutor

```kotlin
// 执行自然语言指令
val result = nlExecutor.execute("打开WiFi")
val result = nlExecutor.execute("给138xxxx发短信")
val result = nlExecutor.execute("返回桌面")
```

---

## 网络端口清单

| 端口 | 协议 | 用途 |
|------|------|------|
| 48765 | UDP | 孢子发现广播 |
| 48766 | TCP | 孢子间数据通信 |
